<!DOCTYPE html>
<html>
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      
    <title>Table</title>
     
    <!-- include material design CSS -->
    <link rel="stylesheet" href="css/materialize-v0.97.8/css/materialize.min.css" />
    <!-- include material design icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <script type="text/javascript" src="js/ajax.js"></script>
    <script type="text/javascript" src="js/jquery-3.1.1.js"></script>
    <!-- custom CSS -->
<style>
.width-30-pct{
    width:30%;
}
 
.text-align-center{
    text-align:center;
}
 
.margin-bottom-1em{
    margin-bottom:1em;
}
</style>
     
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col s12">
            <h4>Products</h4>
            <table class="hoverable bordered">
          <thead>
            <tr>
            <th class="text-align-center">#</th>
            <th class="width-30-pct">First Name</th>
            <th class="width-30-pct">Second Name</th>
            <th class="width-30-pct">Email</th>
            <th class="text-align-center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            require("clases/Conect.php");
            $con = Conectar();
            $sql = "SELECT id, firstname, secondname, email FROM clients";
            $stmt = $con->prepare($sql);
            $result = $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
            foreach($rows as $row){
              ?>
              <tr>
                <td class="text-align-center"><?php print($row->id); ?></td>
                <td class="width-30-pct"><?php print($row->firstname); ?></td>
                <td class="width-30-pct"><?php print($row->secondname); ?></td>
                <td class="text-align-centert"><?php print($row->email); ?></td>
                <td>
                    <a class="waves-effect waves-light btn margin-bottom-1em" onclick="Update('<?php print($row->id); ?>','<?php print($row->firstname); ?>','<?php print($row->secondname); ?>','<?php print($row->email); ?>');"><i class="material-icons left">edit</a>
                    <a class="waves-effect waves-light btn margin-bottom-1em" onclick="Delete('<?php print($row->id); ?>');"><i class="material-icons left">delete</a>
                </td>
              </tr>
              <?php
                }
            ?>
          </tbody>
        </table>
        <div id="modal" class="modal">
        <div class="modal-content">
            <h4>New Client</h4>
      
    <div class="row">
        <form class="col s12" name="frmClientes" onsubmit="Save(idP,accion); return false">
      
      
        <div class="input-field col s12">
          <input id="firstname" type="text" class="validate" required>
          <label for="firstname">First Name</label>
        </div>
        
        <div class="input-field col s12">
          <input id="secondname" type="text" class="validate" required>
          <label for="secondname">Second Name</label>
        </div>
        
        <div class="input-field col s12">
          <input id="email" type="email" class="validate" required>
          <label for="email">Email</label>
        </div>
        <button class="btn waves-effect waves-light" aria-hidden="true" type="submit">Save</button>
        <a class="waves-effect waves-teal btn-flat">Close</a>
    </form>
  </div>
  </div>
  </div>
 <div class="fixed-action-btn" style="bottom:45px; right:24px;">
            <a data-target="modal" onclick="New();" class="waves-effect waves-light btn modal-trigger btn-floating btn-large red"><i class="large material-icons" >add</i></a>
    </div>

    
    
 
<!-- material design js -->
<script src="css/materialize-v0.97.8/js/materialize.min.js"></script>
<script type="text/javascript">
    var accion;
    var idP;
    function New(){
      accion = 'N';
      document.frmClientes.firstname.value = "";
      document.frmClientes.secondname.value = "";
      document.frmClientes.email.value = "";
      $('#modal').modal('show');
    }
    function Update(id, firstname, secondname, email){
      accion = 'E';
      idP = id;
      document.frmClientes.firstname.value = firstname;
      document.frmClientes.secondname.value = secondname;
      document.frmClientes.email.value = email;
      $('#modal').modal('show');
    }

$(document).ready(function(){
    $('.modal').modal();

    
});

    </script>
 
</body>
</html>