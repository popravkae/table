<?php
$firstname = $_POST['firstname'];
$secondname = $_POST['secondname'];
$email = $_POST['email'];
$idP = $_POST['idP'];
require('Conect.php');
$con = Conectar();
$sql = 'UPDATE clients SET firstname=:firstname, secondname=:secondname, email=:email WHERE id=:idPersona';
$q = $con->prepare($sql);
$q->execute(array(':firstname'=>$firstname, ':secondname'=>$secondname, ':email'=>$email, ':idPersona'=>$idP));
?>