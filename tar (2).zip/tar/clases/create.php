<?php
$firstname = $_POST['firstname'];
$secondname = $_POST['secondname'];
$email = $_POST['email'];
require('Conect.php');
$con = Conectar();
$sql = 'INSERT INTO clients (firstname, secondname, email) VALUES (:firstname, :secondname, :email)';
$q = $con->prepare($sql);
$q->execute(array(':firstname'=>$firstname, ':secondname'=>$secondname, ':email'=>$email));
?>