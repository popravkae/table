<?php
$idP = $_POST['idP'];
require('Conect.php');
$con = Conectar();
$sql = 'DELETE FROM clients WHERE id=:idPersona';
$q = $con->prepare($sql);
$q->execute(array(':idPersona'=>$idP));
?>