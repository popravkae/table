<?php
function Conectar(){
  $conn = null;
  $host = 'localhost';
  $db = 'a0105650_test';
  $user = 'a0105650_test';
  $pwd = 'testtest';
  try {
    $conn = new PDO('mysql:host='.$host.';dbname='.$db, $user, $pwd);
  }catch(PDOException $e){
    echo ':( Error '.$e;
    exit;
  }
  return $conn;
}
?>