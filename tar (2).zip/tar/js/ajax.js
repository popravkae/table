function objetoAjax(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
		}
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
}
function Save(idP, accion){
firstname = document.frmClientes.firstname.value;
secondname = document.frmClientes.secondname.value;
email = document.frmClientes.email.value;
ajax = objetoAjax();
if(accion=='N'){
ajax.open("POST", "clases/create.php", true);
}else if(accion=='E'){
ajax.open("POST", "clases/update.php", true);
}
ajax.onreadystatechange=function() {
		if (ajax.readyState==4) {
			alert('The data was saved successfully!');
      window.location.reload(true);
		}
	}
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
ajax.send("firstname="+firstname+"&secondname="+secondname+"&email="+email+"&idP="+idP)
}
function Delete(idP){
if(confirm('Are you sure?')){
ajax = objetoAjax();
ajax.open("POST", "clases/delete.php", true);
ajax.onreadystatechange=function() {
		if (ajax.readyState==4) {
			alert('The data was successfully removed!');
      window.location.reload(true);
		}
	}
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
ajax.send("idP="+idP)
}else{
  //Sin acciones
}
}