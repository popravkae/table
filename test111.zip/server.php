<?php
$db = new PDO('mysql:host=localhost;dbname=a0105650_test','a0105650_test','testtest');
$page = isset($_GET['p'])?$_GET['p']:'';
if ($page=='add') {
	$firstname = $_POST['firstname'];
	$secondname = $_POST['secondname'];
	$email = $_POST['email'];
	$stmt = $db->prepare("insert into clients values('',?,?,?)");
	$stmt->bindParam(1,$firstname);
	$stmt->bindParam(2,$secondname);
	$stmt->bindParam(3,$email);
	if($stmt->execute()){
		echo "Success add data";
	} else{
		echo "Fail add data";
	}


}else if($page=='edit'){
    $id = $_POST['id'];
    $firstname = $_POST['firstname'];
	$secondname = $_POST['secondname'];
	$email = $_POST['email'];
	$stmt = $db->prepare("update clients set firstname=?, secondname=?, email=? where id=?");
	$stmt->bindParam(1,$firstname);
	$stmt->bindParam(2,$secondname);
	$stmt->bindParam(3,$email);
	$stmt->bindParam(4,$id);
	if($stmt->execute()){
		echo "Success update data";
	} else{
		echo "Fail update data";
	}

}else if($page=='del'){
    $id = $_GET[id];
    $stmt = $db->prepare("delete from clients where id=?"); 
    $stmt->bindParam(1,$id);
    if($stmt->execute()){
		echo "Success delete data";
	} else{
		echo "Fail delete data";
	}
    
} else{
	$stmt = $db->prepare("select * from clients order by id desc");
	$stmt->execute();
	while($row = $stmt->fetch()){
		?>
		<tr>
    		<td><?php echo $row['id'] ?></td>
    		<td><?php echo $row['firstname'] ?></td>
    		<td><?php echo $row['secondname'] ?></td>
    		<td><?php echo $row['email'] ?></td>
    		<td>
        		<button  class="btn btn-warning" data-toggle="modal" data-target="#edit-<?php echo $row['id'] ?>">Edit</button>
        		
                <div class="modal fade" id="edit-<?php echo $row['id'] ?>" role="dialog" arial-labelledbly="editLabel">
                <div class="modal-dialog">
                 <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" id="editLabel">Edit Data</h4>
                        </div>
                        <form class="form-horizontal">
                        <div class="modal-body">
                            <input type="hidden" id="<?php echo $row['id'] ?>" value="<?php echo $row['id'] ?>">
                                    <div class="form-group">
                                        <label class="control-label col-sm-2" for="firstname">First name</label>
                                    <div class="col-sm-10">
                                         <input type="text" class="form-control" id="firstname-<?php echo $row['id'] ?>" value="<?php echo $row['firstname'] ?>"> 
                                    </div>
                                    </div>
      
                                  <div class="form-group">
                                    <label class="control-label col-sm-2" for="secondname">Second name</label>
                                    <div class="col-sm-10">
                                      <input type="text" class="form-control" id="secondname-<?php echo $row['id'] ?>" value="<?php echo $row['secondname'] ?>">
                                    </div>
                                  </div>
  
                                  <div class="form-group">
                                    <label class="control-label col-sm-2" for="email">Email:</label>
                                    <div class="col-sm-10">
                                      <input type="email" class="form-control" id="email-<?php echo $row['id'] ?>" value="<?php echo $row['email'] ?>">
                                    </div>
                                  </div>
                                  </div>
                                    <div class="modal-footer">
                                        <button type="submit" onclick="updateData(<?php echo $row['id'] ?>)" class="btn btn-primary">Update</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      
                                    </div>
                                    </div>
                            </form>
                        </div>
                  </div>
            </div> 
        </div>
        		<button onclick="deleteData(<?php echo $row['id'] ?>)" class="btn btn-danger">Delete</button>
    		</td>
		</tr>
		<?php
	}
}
?>